export interface a2Personal{
    myFullName: string;
    sheridanID: number;
    sheridanLogin: string;
    sheridanProgram: string;
    sheridanEmail: string;

}


export interface campusData{
    campus: string;
    street: string;
    city: string;

}
export interface myBooks{
    authorName: string;
    bookTitle: string;
    published: number;

}
